from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from cairo import Status
from django.shortcuts import render
from django.shortcuts import render

from django.utils.text import slugify

from accessory.models import *
from yarn.models import *
from company.models import *
from grey_fabric.models import * 
from employee.models import * 

from purchase_app.models import *
from django.contrib import messages
from django.http import JsonResponse
from django.http import HttpResponseRedirect,HttpResponse,HttpRequest
import bcrypt
from django.db.models import Q
import datetime

from datetime import datetime
from datetime import date
from django.utils import timezone

from django.db.models import Count


from django.views.decorators.csrf import csrf_exempt
from django.http.response import JsonResponse


from django.views.decorators.http import require_http_methods

from django.core.exceptions import ObjectDoesNotExist
import base64 
from django.core.files.base import ContentFile
from django.conf import settings
import hashlib
from django.views.decorators.http import require_POST
from django.shortcuts import get_object_or_404
from decimal import Decimal
from django.db.models import Max
from django.db import IntegrityError

import json 
from django.db import transaction
import logging
from django.db.models import F, OuterRef, Subquery, Value
from dateutil.parser import parse as parse_date 
from django.template.loader import render_to_string
from django.views.decorators.http import require_GET
from django.db.models import Sum
from django.db.models.functions import Coalesce
from django.templatetags.static import static
from django.core.serializers import serialize 
from datetime import timedelta

import uuid 

from openpyxl import load_workbook # excel
from django.core.mail import send_mail
from common.utils import *


from django.contrib.auth import logout as django_logout
from django.contrib.auth.decorators import login_required

from django.core.signing import Signer, BadSignature

import requests
from django.db.models.functions import ExtractYear, ExtractMonth


from django.shortcuts import redirect
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import Flow
from django.middleware.csrf import get_token
from django.conf import settings
from google.auth.transport.requests import AuthorizedSession
import hashlib

from django.utils.text import slugify

from django.core.exceptions import ValidationError

from django.http import HttpResponseBadRequest

from yarn.models import * 
from program_app.models import * 
from user_auth.models import * 
from company.models import * 
from employee.models import * 
from django.utils.timezone import make_aware

from software_app.views import fabric_program, getItemNameById, getSupplier, is_ajax


# `````````````````````````````````````````````````````````````````````````````````


def grey_fab_outward(request):
    if 'user_id' in request.session: 
        user_id = request.session['user_id']
        supplier = party_table.objects.filter(is_supplier=1) 
        # party = party_table.objects.filter(status=1,is_supplier=1)
        party = party_table.objects.filter(status=1).filter(is_mill=1) | party_table.objects.filter(status=1).filter(is_trader=1)
 
        yarn_count = count_table.objects.filter(status=1)
        product = product_table.objects.filter(status=1)

        
        return render(request,'outward/grey_fabric_outward.html',{'supplier':supplier,'party':party,'product':product,'yarn_count':yarn_count})
    else:
        return HttpResponseRedirect("/admin")




# ```````````````````````````` grey fabric inward add ``````````````````



def generate_outward_num_series():
    last_purchase = parent_gf_delivery_table.objects.filter(status=1).order_by('-id').first()
    if last_purchase and last_purchase.do_number:
        match = re.search(r'DO-(\d+)', last_purchase.do_number)
        if match:
            next_num = int(match.group(1)) + 1
        else:
            next_num = 1
    else:
        next_num = 1
        print('new-no:',next_num)
 
    return f"DO-{next_num:03d}"



# def generate_inward_num_series():
#     last_purchase = gf_inward_table.objects.filter(status=1).order_by('-id').first()
#     if last_purchase and last_purchase.inward_number:
#         match = re.search(r'IN-(\d+)', last_purchase.inward_number)
#         if match:
#             next_num = int(match.group(1)) + 1
#         else:
#             next_num = 1
#     else:
#         next_num = 1
 
#     return f"IN-{next_num:03d}"


def grey_fabric_outward_add(request): 
    if 'user_id' in request.session: 
        user_id = request.session['user_id'] 
       
        product = product_table.objects.filter(status=1)
        count = count_table.objects.filter(status=1)

        fabric_program_qs = fabric_program_table.objects.filter(status=1)

        linked_knitting_ids = grey_fabric_po_table.objects.values('program_id')

 
        # ``` dyeing program`````


        # outwards = parent_gf_delivery_table.objects.filter(status=1).values('dyeing_program_id')
        dyeing = dyeing_program_table.objects.filter(status=1)
        # dyeing = dyeing_program_table.objects.filter(status=1).exclude(id__in=outwards)

        # Filter knitting_table
        knitting = knitting_table.objects.filter(status=1, is_grey_fabric=1).exclude(id__in=linked_knitting_ids)
        fabric_program = []
        for fp in fabric_program_qs:
            try:
                fabric_item = fabric_table.objects.get(id=fp.fabric_id)
                print(f"fabric_item: {fabric_item}, ID: {fp.fabric_id}, Name: {getattr(fabric_item, 'name', 'NO NAME')}")
                fabric_program.append({
                    'id': fp.id,
                    'name': fp.name,
                    'fabric_id': fp.fabric_id,
                    'fabric_name': getattr(fabric_item, 'name', 'NO NAME')
                })
            except fabric_table.DoesNotExist:
                print(f"fabric_id {fp.fabric_id} not found in fabric_table")
                fabric_program.append({
                    'id': fp.id,
                    'name': fp.name,
                    'fabric_id': fp.fabric_id,
                    'fabric_name': 'N/A' 
                })
        # party = party_table.objects.filter(status=1).filter(is_mill=1) | party_table.objects.filter(status=1).filter(is_trader=1)
        party = party_table.objects.filter(status=1, is_process=1)
        knitting_party = party_table.objects.filter(status=1,is_knitting=1)
        out_party = party_table.objects.filter(status=1,is_process=1)
        tex = tex_table.objects.filter(status=1)
        gauge = gauge_table.objects.filter(status=1)
        dia = dia_table.objects.filter(status=1)
        do_number = generate_outward_num_series 
 

        program = grey_fab_dyeing_program_balance.objects.filter(
            balance_wt__gt=0
        ).values('program_id', 'fabric_id','dia_id','color_id')

        lot = grey_fabric_available_inward_table.objects.filter(
            available_wt__gt=0
        ).values('lot_no').distinct().order_by('lot_no')

        print('lot:',lot)

        
        program_ids = program.values_list('program_id', flat=True) 

        prg_list = dyeing_program_table.objects.filter(id__in=program_ids, status=1)
        # if prg_list = 

        # print('program',prg_list)
        return render(request, 'outward/grey_fab_outward_add.html', {
            'knitting_party': knitting_party,
            'party': party,
            'out_party':out_party,
            'product': product,
            'count':count,
            'fabric_program':fabric_program, 
            'do_number': do_number,
            'tex':tex,
            'gauge':gauge,
            'dia':dia,
            'knitting':knitting,
            'dyeing':dyeing,
            'program':prg_list ,
            'lot':lot,  
                 
        }) 
    else:
        return HttpResponseRedirect("/admin")



# @csrf_exempt
# def get_grey_inward_lists(request):
#     if request.method == 'POST':
#         lot_no = request.POST.get('lot_no')
#         if not lot_no:
#             return JsonResponse({'error': 'Lot No missing'}, status=400)

#         # Get inward entries for the given dyeing program
#         inwards = gf_inward_table.objects.filter(lot_no__in=lot_no, status=1)

#         lot_nos = inwards.values_list('lot_no', flat=True).distinct()
#         inward_list = inwards.values('id', 'inward_number')

#         return JsonResponse({
#             'lot_nos': list(lot_nos),
#             'inward_list': list(inward_list)
#         })

#     return JsonResponse({'error': 'Invalid request'}, status=405)




def get_party_lists(request):
    party_id = request.POST.get('party_id')
    if not party_id:
        return JsonResponse({'error': 'party_id is required'}, status=400)

    program_ids = set()
    old_program_ids = set()

    # Step 1: Get new programs (out_quantity = 0)
    new_programs = grey_fab_dyeing_program_balance.objects.filter(
        out_wt=0,
        balance_wt__gt=0
 
    ).values_list('program_id', flat=True)

    for program_id in new_programs:
        program_ids.add(program_id)

    # Step 2: Get old programs (out_wt > 0 and balance_wt > 0)
    old_programs_qs = grey_fab_dyeing_program_balance.objects.filter(
        out_wt__gt=0,
        balance_wt__gt=0
    ).values('program_id')

    for row in old_programs_qs:
        program_id = row['program_id']
        count = parent_gf_delivery_table.objects.filter(
            party_id=party_id, 
            program_id=program_id
        ).count()
        if count > 0:
            program_ids.add(program_id)
            old_program_ids.add(program_id)  # Track as old

    # Step 3: Get knitting info
    knitting_qs = knitting_table.objects.filter(id__in=program_ids).values_list('id', 'knitting_number', 'name')
    knitting_map = {row[0]: {'knitting_number': row[1], 'name': row[2]} for row in knitting_qs}

    final_list = []
    for program_id in program_ids:
        knitting_info = knitting_map.get(program_id)
        if not knitting_info:
            continue

        program_entry = {
            'id': program_id,
            'knitting_number': knitting_info['knitting_number'],
            'name': knitting_info['name']
        }

        # Add po_id only for old programs 
        if program_id in old_program_ids:

            po_ids = child_gf_delivery_table.objects.filter(
                program_id=program_id,
                party_id=party_id
            ).values_list('po_id', flat=True).distinct()
            print('po-ids:',po_ids)

            po = parent_po_table.objects.filter(status=1, id__in=po_ids).values('name')
            program_entry['po_ids'] = [p['name'] for p in po] 



            # po_ids = sub_yarn_deliver_table.objects.filter(
            #     program_id=program_id,
            #     party_id=party_id
            # ).values_list('po_id', flat=True).distinct()
            # po = parent_po_table.objects.filter(status=1, id__in=po_ids).values('name')
            # program_entry['po_ids'] = po #list(po_ids)

        final_list.append(program_entry)

    return JsonResponse(final_list, safe=False)



@csrf_exempt
def get_grey_fab_inward(request):
    if request.method == "POST":
        lot_no = request.POST.get("lot_no")

        # Get unique inward_ids
        inward_ids = grey_fabric_available_inward_table.objects.filter(
            lot_no=lot_no,
            available_wt__gt=0
        ).values_list('inward_id', flat=True).distinct()
        print('available-inw:',inward_ids)
        # Get inward_number for each ID
        inward_qs = gf_inward_table.objects.filter(
            id__in=inward_ids,
            status=1,
            is_active=1,
        ).values('id', 'inward_number','total_gross_wt')
        print('inw:',inward_qs)

        return JsonResponse({
            'status': 'success',
            'inward_list': list(inward_qs)
        })






from django.db import connection
from django.http import JsonResponse
import json



from django.db import connection
from django.http import JsonResponse
from django.db.models import Max


def get_grey_fab_inward_detail_list(request):
    if request.method == "POST":
        lot_no = request.POST.get("lot_no")
        tm_id = request.POST.get("prg_id")
        outward_tm_id = request.POST.get("outward_tm_id") or '0'

        if not lot_no or not tm_id:
            return JsonResponse({'status': 'error', 'message': 'lot_no and tm_id are required'})

        query = f"""
            SELECT 
                Y.lot_no,
                Y.program_id,
                Y.fabric_id,
                Y.dia_id, 

                MAX(X.pgm_rolls) AS pgm_rolls,
                MAX(X.pgm_wt) AS pgm_wt,
                MAX(X.out_rolls) AS out_rolls, 
                MAX(X.out_wt) AS out_wt,

                
               
                MAX(Y.total_in_rolls) AS tot_in_rolls,
                MAX(Y.total_in_wt) AS tot_in_wt,
                MAX(Y.total_out_roll) AS tot_out_rolls,
                MAX(Y.total_out_wt) AS tot_out_wt,
                (MAX(Y.total_in_rolls) - MAX(Y.total_out_roll)) AS stock_rolls,
                (MAX(Y.total_in_wt) - MAX(Y.total_out_wt)) AS stock_wt


            FROM (
                SELECT 
                    yi.lot_no,
                    yi.program_id,
                    yi.fabric_id,
                    yi.dia_id,
                    0 AS pgm_rolls,
                    0 AS pgm_wt,
                    SUM(yi.roll) AS total_in_rolls,
                    SUM(yi.gross_wt) AS total_in_wt,
                    0 AS total_out_roll,
                    0 AS total_out_wt,
                    0 AS out_rolls,
                    0 AS out_wt
                FROM tx_gf_inward yi
                WHERE yi.status = 1 AND yi.lot_no = %s
                GROUP BY yi.lot_no, yi.program_id, yi.fabric_id, yi.dia_id

                UNION ALL

                SELECT 
                    yo.lot_no,
                    kp.id AS program_id,
                    yo.fabric_id,
                    yo.dia_id,
                    0 AS pgm_rolls,
                    0 AS pgm_wt,
                    0 AS total_in_rolls,
                    0 AS total_in_wt,
                    SUM(yo.roll) AS total_out_roll,
                    SUM(yo.gross_wt) AS total_out_wt,
                    0 AS out_rolls,
                    0 AS out_wt
                FROM tx_gf_delivery yo
                LEFT JOIN tm_dyeing_program dp ON yo.dyeing_program_id = dp.id
                LEFT JOIN tm_knitting kp ON dp.program_id = kp.id
                WHERE yo.status = 1 AND yo.lot_no = %s
                GROUP BY yo.lot_no, kp.id, yo.fabric_id, yo.dia_id
            ) AS Y

            LEFT JOIN (
                SELECT 
                    '' AS lot_no,
                    yip.tm_id AS program_id,
                    yip.fabric_id,
                    yip.dia AS dia_id,
                    SUM(yip.rolls) AS pgm_rolls,
                    SUM(yip.quantity) AS pgm_wt,
                    0 AS total_in_rolls,
                    0 AS total_in_wt,
                    0 AS total_out_roll,
                    0 AS total_out_wt,
                    0 AS out_rolls,
                    0 AS out_wt
                FROM tx_knitting yip
                WHERE yip.status = 1 AND yip.tm_id = %s
                GROUP BY yip.tm_id, yip.fabric_id, yip.dia

                UNION ALL

                SELECT 
                    yod.lot_no,
                    kp.id,
                    yod.fabric_id,
                    yod.dia_id,
                    0 AS pgm_rolls,
                    0 AS pgm_wt,
                    0 AS total_in_rolls,
                    0 AS total_in_wt,
                    0 AS total_out_roll,
                    0 AS total_out_wt,
                    SUM(yod.roll) AS out_rolls,
                    SUM(yod.gross_wt) AS out_wt
                FROM tx_gf_delivery yod
                LEFT JOIN tm_dyeing_program dp ON yod.dyeing_program_id = dp.id
                LEFT JOIN tm_knitting kp ON dp.program_id = kp.id
                WHERE yod.status = 1 AND yod.tm_id = %s
                GROUP BY yod.lot_no, yod.knitting_program_id, yod.fabric_id, yod.dia_id
            ) AS X 
            ON Y.program_id = X.program_id 
            AND Y.fabric_id = X.fabric_id 
            AND Y.dia_id = X.dia_id

            WHERE Y.lot_no IS NOT NULL

            GROUP BY 
                Y.lot_no,
                Y.fabric_id,
                Y.dia_id
               
        """                # Y.program_id,


        with connection.cursor() as cursor:
            cursor.execute(query, [lot_no, lot_no, tm_id, outward_tm_id])
            columns = [col[0] for col in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            print('res:',results)
        # Collect unique IDs
        unique_program_ids = {row['program_id'] for row in results}
        unique_fabric_ids = {row['fabric_id'] for row in results}
        unique_dia_ids = {row['dia_id'] for row in results}

        programs = knitting_table.objects.filter(status=1, id__in=unique_program_ids).values('id', 'name')
        fabrics = fabric_program_table.objects.filter(status=1, id__in=unique_fabric_ids).values('id', 'name')
        dias = dia_table.objects.filter(status=1, id__in=unique_dia_ids).values('id', 'name')

        sub_knittings = sub_knitting_table.objects.filter(status=1, tm_id__in=unique_program_ids).values(
            'tm_id', 'fabric_id'
        ).annotate(
            gauge_id=Max('gauge'),
            tex_id=Max('tex'),
            gsm=Max('gsm'),
            count_id=Max('count_id'),
        )

        # Lookup maps
        program_map = {p['id']: p['name'] for p in programs}
        fabric_map = {p['id']: p['name'] for p in fabrics}
        dia_map = {d['id']: d['name'] for d in dias}
        sub_knit_map = {(r['tm_id'], r['fabric_id']): r for r in sub_knittings}

        # Related IDs for gauge, tex, gsm, count
        gauge_ids = [r['gauge_id'] for r in sub_knittings if r.get('gauge_id')]
        tex_ids = [r['tex_id'] for r in sub_knittings if r.get('tex_id')]
        gsm_ids = [r['gsm'] for r in sub_knittings if r.get('gsm')]
        count_ids = [r['count_id'] for r in sub_knittings if r.get('count_id')]

        gauge_map = {g.id: g.name for g in gauge_table.objects.filter(status=1, id__in=gauge_ids)}
        tex_map = {t.id: t.name for t in tex_table.objects.filter(status=1, id__in=tex_ids)}
        count_map = {c.id: c.name for c in count_table.objects.filter(status=1, id__in=count_ids)}

        for row in results:
            row['program_name'] = program_map.get(row['program_id'], '')
            row['fabric_name'] = fabric_map.get(row['fabric_id'], '')
            row['dia_name'] = dia_map.get(row['dia_id'], '')

            key = (row['program_id'], row['fabric_id'])
            sub = sub_knit_map.get(key, {})
            row['gauge_id'] = sub.get('gauge_id')
            row['tex_id'] = sub.get('tex_id')
            row['gsm'] = sub.get('gsm')
            row['count_id'] = sub.get('count_id')

            row['gauge_name'] = gauge_map.get(row['gauge_id'], '')
            row['tex_name'] = tex_map.get(row['tex_id'], '')
            row['yarn_count_name'] = count_map.get(row['count_id'], '')
            row['gsm_name'] = row['gsm'] or ''

        return JsonResponse({
            'status': 'success',
            'stock_summary': results, 
            'prg_name': list(programs),
            'fabric_name': list(fabrics),
            'dia_name': list(dias),
        })

    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})



def get_grey_fab_inward_detail_list_16062025(request):
    if request.method == "POST":
        lot_no = request.POST.get("lot_no")
        tm_id = request.POST.get("prg_id")  # Must be passed from frontend for dynamic filtering
        outward_tm_id = request.POST.get("outward_tm_id")  # For optional outward roll data
        print('program-id:',tm_id)
        # Safety check
        if not lot_no or not tm_id:
            return JsonResponse({'status': 'error', 'message': 'lot_no and tm_id are required'})

        # Default outward_tm_id if not provided
        outward_tm_id = outward_tm_id or '0'
#  SELECT 
#             Y.lot_no,
#             Y.program_id,
#             Y.fabric_id,
#             Y.dia_id, 

#             X.pgm_rolls,
#             X.pgm_wt,
#             X.out_rolls,
#             X.out_wt,

#             SUM(Y.total_in_rolls) AS tot_in_rolls,
#             SUM(Y.total_in_wt) AS tot_in_wt,
#             SUM(Y.total_out_roll) AS tot_out_rolls,
#             SUM(Y.total_out_wt) AS tot_out_wt,

#             (SUM(Y.total_in_rolls) - SUM(Y.total_out_roll)) AS stock_rolls,
#             (SUM(Y.total_in_wt) - SUM(Y.total_out_wt)) AS stock_wt

        query = f"""
       SELECT 
            Y.lot_no,
            Y.program_id,
            Y.fabric_id,
            Y.dia_id, 

            SUM(X.pgm_rolls) AS pgm_rolls,
            SUM(X.pgm_wt) AS pgm_wt,
            SUM(X.out_rolls) AS out_rolls,
            SUM(X.out_wt) AS out_wt,

            SUM(Y.total_in_rolls) AS tot_in_rolls,
            SUM(Y.total_in_wt) AS tot_in_wt,
            SUM(Y.total_out_roll) AS tot_out_rolls, 
            SUM(Y.total_out_wt) AS tot_out_wt,

            (SUM(Y.total_in_rolls) - SUM(Y.total_out_roll)) AS stock_rolls,
            (SUM(Y.total_in_wt) - SUM(Y.total_out_wt)) AS stock_wt
        FROM (
            SELECT 
                yi.lot_no,
                yi.program_id,
                yi.fabric_id,
                yi.dia_id,
                0 AS pgm_rolls,
                0 AS pgm_wt,
                SUM(yi.roll) AS total_in_rolls,
                SUM(yi.gross_wt) AS total_in_wt,
                0 AS total_out_roll,
                0 AS total_out_wt,
                0 AS out_rolls,
                0 AS out_wt
            FROM tx_gf_inward yi
            WHERE yi.status = 1 AND yi.lot_no = %s
            GROUP BY yi.lot_no, yi.program_id, yi.fabric_id, yi.dia_id

            UNION ALL

            SELECT 
                yo.lot_no,
                kp.id AS program_id,
                yo.fabric_id,
                yo.dia_id,
                0 AS pgm_rolls,
                0 AS pgm_wt,
                0 AS total_in_rolls,
                0 AS total_in_wt,
                SUM(yo.roll) AS total_out_roll,
                SUM(yo.gross_wt) AS total_out_wt,
                0 AS out_rolls,
                0 AS out_wt
            FROM tx_gf_delivery yo
            LEFT JOIN tm_dyeing_program dp ON yo.program_id = dp.id
            LEFT JOIN tm_knitting kp ON dp.program_id = kp.id
            WHERE yo.status = 1 AND yo.lot_no = %s
            GROUP BY yo.lot_no, kp.id, yo.fabric_id, yo.dia_id
        ) AS Y

        LEFT JOIN (
            SELECT 
                '' AS lot_no,
                yip.tm_id AS program_id,
                yip.fabric_id,
                yip.dia AS dia_id,
                SUM(yip.rolls) AS pgm_rolls,
                SUM(yip.quantity) AS pgm_wt,
                0 AS total_in_rolls,
                0 AS total_in_wt,
                0 AS total_out_roll,
                0 AS total_out_wt,
                0 AS out_rolls,
                0 AS out_wt
            FROM tx_knitting yip
            WHERE yip.status = 1 AND yip.tm_id = %s
            GROUP BY yip.tm_id, yip.fabric_id, yip.dia

            UNION ALL

            SELECT 
                yod.lot_no,
                kp.id,
                yod.fabric_id,
                yod.dia_id,
                0 AS pgm_rolls,
                0 AS pgm_wt,
                0 AS total_in_rolls,
                0 AS total_in_wt,
                0 AS total_out_roll,
                0 AS total_out_wt,
                SUM(yod.roll) AS out_rolls,
                SUM(yod.gross_wt) AS out_wt
            FROM tx_gf_delivery yod
            LEFT JOIN tm_dyeing_program dp ON yod.program_id = dp.id
            LEFT JOIN tm_knitting kp ON dp.program_id = kp.id
            WHERE yod.status = 1 AND yod.tm_id = %s

            GROUP BY yod.lot_no, yod.program_id, yod.fabric_id, yod.dia_id
        ) AS X 
        ON Y.program_id = X.program_id 
        AND Y.fabric_id = X.fabric_id 
        AND Y.dia_id = X.dia_id

        WHERE Y.lot_no IS NOT NULL
            
        GROUP BY 
            Y.lot_no,
            Y.program_id,
            Y.fabric_id,
            Y.dia_id,
            X.out_rolls,
            X.out_wt


    
        """
  # GROUP BY 
        #     Y.lot_no,
        #     Y.program_id,
        #     Y.fabric_id,
        #     Y.dia_id,
        #     X.pgm_rolls,
        #     X.pgm_wt,
        #     X.out_rolls, 
        #     X.out_wt
        with connection.cursor() as cursor:
            cursor.execute(query, [lot_no, lot_no, tm_id, outward_tm_id])
            columns = [col[0] for col in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            print('stock:', results)

            # Step 1: Extract unique program_ids
            unique_program_ids = set(row['program_id'] for row in results)
            unique_fabric_ids = set(row['fabric_id'] for row in results)
            unique_dia_ids = set(row['dia_id'] for row in results)

            # Step 2: Get related data in bulk
            programs = knitting_table.objects.filter(status=1,id__in=unique_program_ids).values('id', 'name')
            fabrics = fabric_program_table.objects.filter(status=1,id__in=unique_program_ids).values('id', 'name')
            dias = dia_table.objects.filter(status=1,id__in=unique_dia_ids).values('id', 'name')


            # ✅ Fix this line
            fabrics = fabric_program_table.objects.filter(status=1,id__in=unique_fabric_ids).values('id', 'name')

            # Then this works correctly:
            fabric_map = {p['id']: p['name'] for p in fabrics}


            sub_knittings = sub_knitting_table.objects.filter(status=1,
                tm_id__in=unique_program_ids
            ).values(
                'tm_id', 'fabric_id'
            ).annotate(
                gauge_id=Max('gauge'),
                tex_id=Max('tex'),
                gsm=Max('gsm'),
                count_id=Max('count_id'),
            )

            sub_knit_map = {
                (item['tm_id'], item['fabric_id']): {
                    'gauge_id': item['gauge_id'],
                    'tex_id': item['tex_id'],
                    'gsm': item['gsm'],
                    'count_id': item['count_id'],
                }
                for item in sub_knittings
            }

            # Build fast lookup maps
            program_map = {p['id']: p['name'] for p in programs}
            fabric_map = {p['id']: p['name'] for p in fabrics}
            gauge_ids = [r['gauge_id'] for r in sub_knittings if r.get('gauge_id')]
            tex_ids = [r['tex_id'] for r in sub_knittings if r.get('tex_id')] 
            gsm_ids = [r['gsm'] for r in sub_knittings if r.get('gsm')]
            yarn_ids = [r['count_id'] for r in sub_knittings if r.get('count_id')]

            gauge_map = {g.id: g.name for g in gauge_table.objects.filter(status=1,id__in=gauge_ids)}
            tex_map = {t.id: t.name for t in tex_table.objects.filter(status=1,id__in=tex_ids)}
            # gsm_map = {g.id: g.name for g in gsm_table.objects.filter(status=1,id__in=gsm_ids)}

                    #     #     row['gsm_name'] = gsm_map.get(row.get('gsm'), '')

            yarn_map = {y.id: y.name for y in count_table.objects.filter(status=1,id__in=yarn_ids)}
            fab = {y.id: y.name for y in fabric_program_table.objects.filter(status=1,id__in=fabric_map)}



            for row in results:
                row['program_name'] = program_map.get(row['program_id'], '')
                row['fabric_name'] = fabric_map.get(row['fabric_id'], '')

                key = (row['program_id'], row['fabric_id'])
                sub_data = sub_knit_map.get(key, {})
                row['gauge_id'] = sub_data.get('gauge_id')
                row['tex_id'] = sub_data.get('tex_id')
                row['gsm'] = sub_data.get('gsm')  # Already storing GSM
                row['count_id'] = sub_data.get('count_id')

                row['gauge_name'] = gauge_map.get(row.get('gauge_id'), '')
                row['tex_name'] = tex_map.get(row.get('tex_id'), '')
                row['gsm_name'] = row.get('gsm', '')  # ✅ Use raw GSM
                row['yarn_count_name'] = yarn_map.get(row.get('count_id'), '')
                row['fabric_name'] = fab.get(row.get('fabric_id'), '')  # ✅ Use final resolved name


        return JsonResponse({ 
            'status': 'success',
            'stock_summary': results, 
            'prg_name': list(programs),
            'fabric_name': list(fabrics),
            'dia_name': list(dias),
        })


    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

from collections import defaultdict
from django.http import JsonResponse




@csrf_exempt
def dyeing_program_list(request): 
    if request.method == 'POST':
        master_id = request.POST.get('prg_id')

        if not master_id:
            return JsonResponse({'message': 'error', 'error': 'Missing ID'})

        try:
            child_data = sub_dyeing_program_table.objects.filter(
                tm_id=master_id, status=1, is_active=1
            ) 

            dia_set = set()
            grouped_data = defaultdict(lambda: {'dias': {}})


            for item in child_data:
                fabric = getItemFabNameById(fabric_program_table, item.fabric_id)
                color = getItemNameById(color_table, item.color_id)
                dia = getItemNameById(dia_table, item.dia_id)

                key = (fabric, color)
                dia_set.add((item.dia_id, dia))  # tuple of (id, name)

                grouped_data[key]['fabric'] = fabric
                grouped_data[key]['color'] = color
                grouped_data[key]['fabric_id'] = item.fabric_id
                grouped_data[key]['color_id'] = item.color_id
                grouped_data[key]['dias'][dia] = {
                    'dia_id': item.dia_id,
                    'roll': item.roll or 0,
                    'roll_wt': item.roll_wt or 0
                }

            rows = []
            for (fabric, color), data in grouped_data.items():
                row = {
                    'fabric': data['fabric'],
                    'fabric_id': data['fabric_id'],
                    'color': data['color'],
                    'color_id': data['color_id']
                }
                for dia_id, dia_name in dia_set:
                    row[dia_name] = data['dias'].get(dia_name, {
                        'dia_id': dia_id,
                        'roll': 0,
                        'roll_wt': 0
                    })
                rows.append(row)

            fabric_ids = child_data.values_list('fabric_id', flat=True).distinct()
            print('fab-ids:',fabric_ids)
            lots = grey_fabric_available_inward_table.objects.filter(
                available_wt__gt=0,
                fabric_id__in=fabric_ids
            ).values_list('lot_no', flat=True).distinct().order_by('lot_no')

            return JsonResponse({
                'dias': sorted(list(dia_set), key=lambda x: x[1]),  # sorted by name
                'rows': rows,
                'lots': list(lots),
            })




            # for item in child_data:
            #     fabric = getItemFabNameById(fabric_program_table, item.fabric_id)
            #     color = getItemNameById(color_table, item.color_id)
            #     dia = getItemNameById(dia_table, item.dia_id)

            #     key = (fabric, color)
            #     dia_set.add(dia)

            #     grouped_data[key]['fabric'] = fabric
            #     grouped_data[key]['color'] = color
            #     grouped_data[key]['dias'][dia] = {
            #         'roll': item.roll or 0,
            #         'roll_wt': item.roll_wt or 0
            #     }

            # rows = []
            # for (fabric, color), data in grouped_data.items():
            #     row = {'fabric': fabric, 'color': color}
            #     for dia in dia_set:
            #         row[dia] = data['dias'].get(dia, {'roll': 0, 'roll_wt': 0})
            #     rows.append(row)


            # # Get all unique fabric IDs involved in the selected program
            # fabric_ids = child_data.values_list('fabric_id', flat=True).distinct()

            # # Filter lot_no based on those fabric IDs
            # lots = grey_fabric_available_inward_table.objects.filter(
            #     available_wt__gt=0,
            #     fabric_id__in=fabric_ids
            # ).values_list('lot_no', flat=True).distinct().order_by('lot_no')

            # return JsonResponse({
            #     'dias': sorted(list(dia_set)),
            #     'rows': rows,
            #     'lots': list(lots),  # Include in response
            # })

            # return JsonResponse({
            #     'dias': sorted(list(dia_set)),
            #     'rows': rows
            # })

        except Exception as e:
            return JsonResponse({'message': 'error', 'error': str(e)})

    return JsonResponse({'message': 'error', 'error': 'Invalid request method'})





# @csrf_exempt
# def dyeing_program_list(request): 
#     if request.method == 'POST':
#         master_id = request.POST.get('prg_id')
#         print('dyeing-ID:', master_id) 

#         if master_id: 
#             try:
#                 child_data = sub_dyeing_program_table.objects.filter(
#                     tm_id=master_id, status=1, is_active=1
#                 )

#                 dias_set = set()
#                 data_map = {}

#                 for item in child_data:
#                     fabric_name = getItemFabNameById(fabric_program_table, item.fabric_id)
#                     color_name = getItemNameById(color_table, item.color_id)
#                     dia = getItemNameById(dia_table, item.dia_id)

#                     dias_set.add(dia)

#                     key = (fabric_name, color_name)
#                     if key not in data_map:
#                         data_map[key] = {}

#                     data_map[key][dia] = {
#                         "roll": item.roll or 0,
#                         "roll_wt": float(item.roll_wt or 0)
#                     }

#                 dias_list = sorted(dias_set, key=lambda x: int(x))  # e.g., ["24", "26", "30"]

#                 rows = []
#                 for (fabric, color), dia_data in data_map.items():
#                     row = {
#                         "fabric": fabric,
#                         "color": color
#                     }
#                     for dia in dias_list:
#                         row[dia] = dia_data.get(dia, None)
#                     rows.append(row)

#                 return JsonResponse({
#                     "dias": dias_list,
#                     "rows": rows
#                 })

#             except Exception as e:
#                 return JsonResponse({'error': str(e)})

#         else:
#             return JsonResponse({'error': 'Invalid request, missing ID parameter'})
#     else:
#         return JsonResponse({'error': 'Invalid request, POST method expected'})


# @csrf_exempt
# def dyeing_program_list(request): 
#     if request.method == 'POST':
#         master_id = request.POST.get('prg_id')
#         print('dyeing-ID:', master_id) 

#         if master_id: 
#             try:
#                 # Fetch child dyeing program entries
#                 child_data = sub_dyeing_program_table.objects.filter(
#                     tm_id=master_id, status=1, is_active=1
#                 )

#                 formatted_data = []

#                 for index, item in enumerate(child_data, start=1):
#                     formatted_data.append({
#                         'action': f'''
#                             <button type="button" onclick="knitting_prg_detail_edit('{item.id}')" class="btn btn-primary btn-xs">
#                                 <i class="feather icon-edit"></i>
#                             </button>
#                             <button type="button" onclick="knitting_detail_delete('{item.id}')" class="btn btn-danger btn-xs">
#                                 <i class="feather icon-trash-2"></i>
#                             </button>
#                         ''',
#                         'id': index,
#                         'fabric_id': getItemFabNameById(fabric_program_table, item.fabric_id),
#                         'dia': getItemNameById(dia_table, item.dia_id),
#                         'color': getItemNameById(color_table, item.color_id),
#                         'fabric_id_raw': item.fabric_id,
#                         'dia_id_raw': item.dia_id,
#                         'roll': item.roll or '-',
#                         'roll_wt': item.roll_wt or '-',
#                         'status': '<span class="badge text-bg-success">Active</span>' if item.is_active else '<span class="badge text-bg-danger">Inactive</span>'
#                     })

#                 formatted_data.reverse()

#                 return JsonResponse({
#                     'data': formatted_data
#                 })

#             except Exception as e:
#                 return JsonResponse({'error': str(e)})

#         else:
#             return JsonResponse({'error': 'Invalid request, missing ID parameter'})
#     else:
#         return JsonResponse({'error': 'Invalid request, POST method expected'})


# `````````````````````````````````````````````````` add outward ``````````````````````````````````````````


def insert_grey_fab_outward(request):
    if request.method == 'POST':
        user_id = request.session['user_id']
        company_id = request.session['company_id']
        try: 
            # Extracting data from the request
            do_date = request.POST.get('outward_date') 
            # receive_date = request.POST.get('receive_date') 
            # raw_date = request.POST.get('receive_date')
            
            lot_no = request.POST.get('lot_no')
            inward_id = request.POST.get('inward_id') 
            program_id = request.POST.get('program_id')
            # po_id = request.POST.get('po_id')
            deliver_id = request.POST.get('party_id')
            remarks = request.POST.get('remarks') 
            dye_prg_id = request.POST.get('prg_id') 
            do_number = request.POST.get('do_number')
            chemical_data = json.loads(request.POST.get('chemical_data', '[]')) 

            print('data:',chemical_data)
          
            # Get PO IDs 
            # po_ids = request.GET.getlist('po_id[]')  
            # po_ids_str = ",".join(po_ids)
            # tx_inward_str = ",".join([str(i) for i in tx_inward])  # Convert to string

            # Create a new entry in yarn_delivery_table (Parent table)

            # do_number = generate_do_num_series(yarn_delivery_table, 'do_number', padding=3, prefix='DO')
            material_request = parent_gf_delivery_table.objects.create(
                do_number=do_number,
                company_id=company_id,
                cfyear = 2025,
              
                delivery_date=do_date, 
                party_id=deliver_id,
                knitting_program_id=program_id, 
                dyeing_program_id=dye_prg_id,
                inward_id= 0, #inward_id or 0,
                lot_no=lot_no,
                total_wt= 0,#request.POST.get('total_wt',0.0),
                gross_wt=0, # request.POST.get('sub_total',0.0),
              
                remarks=remarks,
                created_by=user_id,
                # created_on=datetime.now()
            )
            print('material:',material_request)

           
            
            total_gross = Decimal('0.00')
            total_quantity = Decimal('0.00')  # use Decimal for both if you're working with decimals

            for item in chemical_data:
                inward = item.get('inward_id' , 0)
                fabric_id = item.get('fabric_id')
                yarn_count_id = item.get('yarn_count_id')
                gauge_id = item.get('gauge_id')
                tex_id = item.get('tex_id')
                dia_id = item.get('dia_id') 
                gsm = item.get('gsm') 
                roll = item.get('roll') 

                # Create sub yarn delivery entry
                child_gf_delivery_table.objects.create(
                    company_id=company_id,
                    cfyear=2025, 
                    tm_id=material_request.id, 
                   
                    knitting_program_id = program_id,
                    dyeing_program_id=dye_prg_id, 

                    lot_no = lot_no,
                    party_id=deliver_id,
                    yarn_count_id=yarn_count_id,
                    fabric_id=fabric_id,
                    gauge_id=gauge_id,
                    tex_id=tex_id,
                    gsm=gsm,
                    dia_id = dia_id,
                    roll=roll, 
                    # inward_id=inward,
                    inward_id =0,  #item.get('inward_id' | 0)



                    roll_wt=item.get('roll_wt'),
                    gross_wt=item.get('gross_wt', 0),
                    created_by=user_id,
                    # created_on=datetime.now()
                )

                # Convert and accumulate
                try:
                    gross = Decimal(str(item.get('gross_wt', 0)))
                except (InvalidOperation, TypeError):
                    gross = Decimal('0.00') 

                try:
                    qty = Decimal(str(item.get('roll_wt', 0)))
                except (InvalidOperation, TypeError):
                    qty = Decimal('0.00')

                total_gross += gross
                total_quantity += qty
                print('tot:', total_gross, total_quantity)

            material_request.total_wt = total_quantity
            material_request.gross_wt = total_gross
            material_request.save()   
                            

            # 🔹 **Update Parent PO Table (`po_table`)**
            # print('knt-deliver',True)
            # parent_po_table.objects.filter(id__in=po_ids).update(is_knitting_delivery=1)
            new_do_number = generate_outward_num_series()
            return JsonResponse({
                'status': 'success', 
                'message': 'Outward data saved successfully.',  
                "do_number": new_do_number  # e.g., "PO-12345"
            })
            # return JsonResponse('yes', safe=False)  # Indicate success

        except Exception as e:
            print(f"❌ Error: {e}")  # Log error for debugging
            return JsonResponse({'status': 'error', 'message': str(e)})

    return render(request, 'yarn_outward/yarn_outward_add.html')


 

def grey_fab_outward_ajax_report(request):
    company_id = request.session['company_id']
    print('company_id:', company_id)



    query = Q() 

    # Date range filter
    party = request.POST.get('party', '')
    knitting = request.POST.get('knitting', '')
    start_date = request.POST.get('from_date', '')
    end_date = request.POST.get('to_date', '')

    if start_date and end_date:
        try:
            start_date = make_aware(datetime.strptime(start_date, '%Y-%m-%d'))
            end_date = make_aware(datetime.strptime(end_date, '%Y-%m-%d'))

            # Match if either created_on or updated_on falls in range
            date_filter = Q(delivery_date__range=(start_date, end_date)) | Q(updated_on__range=(start_date, end_date))
            query &= date_filter
        except ValueError:
            return JsonResponse({
                'data': [],
                'message': 'error',
                'error_message': 'Invalid date format. Use YYYY-MM-DD.'
            })
    
    if party:
            query &= Q(party_id=party)


    if knitting:
            query &= Q(knittng_program_id=knitting)

    # Apply filters
    queryset = parent_gf_delivery_table.objects.filter(status=1).filter(query)
    data = list(queryset.order_by('-id').values())




    def getInwardNumberById(inward_model, inward_id):
        try:
            entry = inward_model.objects.get(id=inward_id)
            return entry.inward_number
        except inward_model.DoesNotExist:
            return '-'

    # data = list(yarn_delivery_table.objects.filter(status=1).order_by('-id').values())

    formatted = [
        {
            'action': '<button type="button" onclick="grey_outward_edit(\'{}\')" class="btn btn-primary btn-xs"><i class="feather icon-edit"></i></button> \
                        <button type="button" onclick="grey_outward_delete(\'{}\')" class="btn btn-danger btn-xs"><i class="feather icon-trash-2"></i></button> \
                        <button type="button" onclick="grey_outward_print(\'{}\')" class="btn btn-info btn-xs"><i class="feather icon-printer"></i></button>'.format(item['id'],item['id'], item['id']),
                        # <button type="button" onclick="outward_print(\'{}\')" class="btn btn-info btn-xs"><i class="feather icon-printer"></i></button>'.format(item['id'],item['id'], item['program_id']),
            'id': index + 1, 
            'delivery_date': item['delivery_date'].strftime('%d-%m-%Y') if item['delivery_date'] else '-',
            'inward_no': getInwardNumberById(gf_inward_table, item['inward_id']) if item.get('inward_id') else '-',
            'deliver_no': item['do_number'] if item['do_number'] else '-',
            'total_quantity': item['total_wt'] if item['total_wt'] else '-',
            'lot_no': item['lot_no'] if item['lot_no'] else '-',
            'gross_wt': item['gross_wt'] if item['gross_wt'] else '-',
            'party': getSupplier(party_table, item['party_id']),
            # 'po_number': getPONumberByInwardID(yarn_inward_table, item['inward_id']),
            'knit_prg': getKnittingDisplayNameById(knitting_table, item['knitting_program_id']),
            'prg': getDyeingDisplayNameById(dyeing_program_table, item['dyeing_program_id']),
            'status': '<span class="badge bg-success">active</span>' if item['is_active'] else '<span class="badge bg-danger">Inactive</span>',
        }
        for index, item in enumerate(data)
    ]

    return JsonResponse({'data': formatted})

def getDyeingDisplayNameById(tbl, supplier_id):
    try:
        obj = tbl.objects.get(id=supplier_id)
        return f"{obj.name} - {obj.program_no}"
    except tbl.DoesNotExist:
        return "-"



def getKnittingDisplayNameById(tbl, supplier_id):
    try:
        obj = tbl.objects.get(id=supplier_id)
        return f"{obj.name} - {obj.knitting_number}"
    except tbl.DoesNotExist:
        return "-"



@csrf_exempt
def grey_fab_outward_print(request):
    outward_id = request.GET.get('k')
    order_id = base64.b64decode(outward_id)
    print('print-id:',order_id)
    
    if not order_id:
        return JsonResponse({'error': 'Order ID not provided'}, status=400)

    delivery_data = parent_gf_delivery_table.objects.filter(status=1, id=order_id).first()
    # print('delivery:',delivery)


    outward = parent_gf_delivery_table.objects.filter(id = order_id,status=1).values('id','dyeing_program_id','do_number','delivery_date', 'lot_no','party_id', 'total_wt', 'gross_wt')
    print('out:',outward)


    program_details = []
    delivery_details = []
    # ✅ Initialize totals here
    total_roll = 0
    total_quantity = 0

    total_out_rolls = 0
    total_out_wt = 0

    
    # Then build the delivery details (independent of above)
    for out in outward:


        # ````````````````````````````````````

        total_values = get_object_or_404(dyeing_program_table, id=out['dyeing_program_id'])

        print('program-ids:',total_values)
        # customer_value = get_object_or_404(party_table, status=1, id=total_values.party_id)
        program = dyeing_program_table.objects.filter(id=out['dyeing_program_id'], status=1).values('id', 'program_no', 'program_date').first()
        if not program:
            return JsonResponse({'error': 'Program not found'}, status=404)

        kn = program['program_no']
        print('prg-no:', program, kn)

        details = (
            sub_dyeing_program_table.objects.filter(tm_id=out['dyeing_program_id'],status=1) 
            
            .values('fabric_id', 'dia_id', 'color_id','roll','roll_wt')
        )
        
 

        # previous_outwards = (
        #     yarn_delivery_table.objects
        #     .filter(program_id=out['program_id'], status=1, id__lt=out['id'])
        #     .order_by('-id')
        #     .values_list('do_number', flat=True)
        # )

        # pre_no = ", ".join(previous_outwards) if previous_outwards else '-'

        previous_outwards = ( 
            parent_gf_delivery_table.objects
            .filter(dyeing_program_id=out['dyeing_program_id'], status=1, id__lt=out['id'])
            .order_by('-id') 
            .values_list('total_wt', flat=True)
        )
        pre_qty = sum(previous_outwards) if previous_outwards else '-'
        # pre_no = ", ".join(previous_outwards) if previous_outwards else '-'

        # First, build the program details (should run once per detail)
        for detail in details: 
            # yarn_count = get_object_or_404(count_table, id=detail['yarn_count_id'])
            # gauge = get_object_or_404(gauge_table, id=detail['gauge_id'])
            # tex = get_object_or_404(tex_table, id=detail['tex_id'])
            dia = get_object_or_404(dia_table, id=detail['dia_id'])
            color = get_object_or_404(color_table, id=detail['color_id'])
            # fabric = get_object_or_404(fabric_program_table, id=detail['fabric_id'])
            fabric = get_object_or_404(fabric_program_table, id=detail['fabric_id'])
            fab_id = fabric.fabric_id

            # Use get instead of filter to fetch a single fabric record
            fabric_obj = get_object_or_404(fabric_table, id=fab_id, status=1)
            #fabric_display_name = f"{fabric.name} - {fabric_obj.name}"  # Combine program name and fabric name
            fabric_display_name = f"{fabric_obj.name}"  # Combine program name and fabric name


            # total_roll = sum( detail['rolls'] or 0 )
            # total_quantity = sum( detail['quantity'] or 0 )
            rolls = detail['roll'] or 0
            quantity = detail['roll_wt'] or 0

            total_roll += rolls
            total_quantity += quantity
            print('total-rolss;',total_roll)

            program_details.append({
                # 'name': yarn_count.name,
                'fabric': fabric_display_name,
                # 'gauge': gauge.name,   
                # 'gsm': detail['gsm'],
                # 'tex': tex.name,
                'dia': dia.name,
                'color': color.name,
                'roll_wt': detail['roll_wt'], 
                'roll': detail['roll'],
                'wt_per_roll': detail['roll_wt'],
                'program_details': program_details,
                
            })

 


        tx_yarn = (
            child_gf_delivery_table.objects.filter(tm_id=out['id'],status=1) 
            .values('fabric_id','gauge_id','tex_id','dia_id','gsm','yarn_count_id','party_id','roll', 'roll_wt','gross_wt')
            .first()
        )
        print('tx-outward:',tx_yarn)
        total_out_rolls += tx_yarn['roll']
        total_out_wt += tx_yarn['roll_wt']

    
    

        # print('mill_name:',mill_name.name)
        yarn_count = get_object_or_404(count_table, id=tx_yarn['yarn_count_id'])
        gauge = get_object_or_404(gauge_table, id=tx_yarn['gauge_id'])
        tex = get_object_or_404(tex_table, id=tx_yarn['tex_id']) 
        dia = get_object_or_404(dia_table, id=tx_yarn['dia_id'])
        fabric = get_object_or_404(fabric_program_table, id=tx_yarn['fabric_id'])

        if tx_yarn:
            party = get_object_or_404(party_table, id=tx_yarn['party_id']) 
            gstin = party.gstin
            mobile = party.mobile
            delivery_details.append({
                'mill': party.name,
                'yarn': yarn_count.name,
                'fabric': fabric.name,
                'tex': tex.name,
                'gauge': gauge.name,
                'gsm': tx_yarn['gsm'],
                'dia': dia.name, 
                'lot_no':out['lot_no'],
                'do_number':out['do_number'],
                'do_date':out['delivery_date'],
                'roll': tx_yarn['roll'],
                'roll_wt': tx_yarn.get('roll_wt'),
                'gross_wt': tx_yarn['gross_wt'],
            })
            print('delivery_details:',delivery_details)

  
  
    # image_url = 'http://localhost:8000/static/assets/images/mira.png'
    image_url = 'http://mpms.ideapro.in:7026/static/assets/images/mira.png'

    delivery = parent_gf_delivery_table.objects.filter(status=1, id=order_id).values('remarks').first()
    remarks = delivery['remarks'] if delivery else ''
    print('image_url:',image_url)

    # pre_no = previous_outward['do_number']
    context = { 
        'total_values': total_values,
        # 'out_no':delivery_data,
        'gstin':gstin,
        'mobile':mobile,
        'program_details': program_details,
        'total_roll': total_roll,
        'total_quantity': total_quantity,

        'total_out_rolls':total_out_rolls,
        'total_out_wt':total_out_wt,

        'delivery_details': delivery_details,
        'company':company_table.objects.filter(status=1).first(),

        'program':program,
        'image_url':image_url,
        'remarks':remarks,
        'previous_no':pre_qty if pre_qty else '-',


    } 

    return render(request, 'outward/outward_print.html', context)


 


def grey_fab_outward_edit(request):
    try:
        encoded_id = request.GET.get('id')
        if not encoded_id:
            return render(request, 'outward/grey_fab_outward_details.html', {'error_message': 'ID is missing.'})

        # Ensure valid Base64 padding before decoding
        try:
            decoded_id = base64.urlsafe_b64decode(encoded_id + '=' * (-len(encoded_id) % 4)).decode()
            material_id = int(decoded_id)
        except (ValueError, TypeError, base64.binascii.Error):
            return render(request, 'outward/grey_fab_outward_details.html', {'error_message': 'Invalid ID format.'})

        # Fetch material instance
        material_instance = child_gf_delivery_table.objects.filter(tm_id=material_id).first()

        # If no material found and request is POST, create a new one
        if not material_instance and request.method == "POST":
            product_id = request.POST.get('product_id')
            bag = request.POST.get('bag')
            per_bag = request.POST.get('per_bag')
            quantity = request.POST.get('quantity')
            rate = request.POST.get('rate')
            amount = request.POST.get('amount')

            # Validate required fields before saving
            if product_id and quantity:
                material_instance = child_gf_delivery_table.objects.create(
                    tm_id=material_id,
                    bag=bag,
                    per_bag=per_bag,
                    # amount=amount, 
                    # rate=rate, 
                    quantity=quantity
                )
            else:
                return render(request, 'outward/grey_fab_outward_details.html', {'error_message': 'Product details are incomplete.'})

        # Fetch the parent stock instance
        parent_stock_instance = parent_gf_delivery_table.objects.filter(id=material_id).first()

        print('pt:',parent_stock_instance.lot_no)
        if not parent_stock_instance:
            return render(request, 'outward/grey_fab_outward_details.html', {'error_message': 'Parent stock not found.'})

        # Fetch supplier name
        supplier_name = "-"
        if parent_stock_instance.party_id:
            supplier = party_table.objects.filter(id=parent_stock_instance.party_id, status=1).first()
            supplier_name = supplier.name if supplier else "-"
        count = count_table.objects.filter(status=1) 
        fabric = fabric_program_table.objects.filter(status=1) 
        gauge = gauge_table.objects.filter(status=1) 
        dia = dia_table.objects.filter(status=1) 
        tex = tex_table.objects.filter(status=1) 
        # Fetch related data



        # program = grey_fab_dyeing_program_balance.objects.filter(
        #     balance_wt__gt=0
        # ).values('program_id', 'fabric_id','dia_id','color_id')

        lot = grey_fabric_available_inward_table.objects.filter(
            # available_wt__gt=0
        ).values('lot_no').distinct().order_by('lot_no')

        print('lot:',lot)

        
        # program_ids = program.values_list('program_id', flat=True)
 
        prg_list = dyeing_program_table.objects.filter( status=1)
        
        context = { 
            'material': material_instance,
            'parent_stock_instance': parent_stock_instance,
            'party': party_table.objects.filter(is_process=1 ),
            'program': knitting_table.objects.filter(status=1),
            'yarn_count':count,
            'fabric':fabric,
            'gauge':gauge,
            'tex':tex,
            'dia':dia,
            'inward_lists':gf_inward_table.objects.filter(status=1),
            'prg_list':prg_list,
            'lot_no':lot,
        }

        return render(request, 'outward/grey_fab_outward_details.html', context)

    except Exception as e:
        # logger.error(f"Error in yarn_deliver_edit: {e}") 
        return render(request, 'outward/grey_fab_outward_details.html', {'error_message': f'An unexpected error occurred: {str(e)}'})

 



def grey_fab_outward_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')

        try:
            # First, get the delivery record
            delivery = parent_gf_delivery_table.objects.filter(id=data_id, is_active=1).first()
            if not delivery:
                return JsonResponse({'message': 'no such delivery record'})

            ## Now check if the corresponding inward record exists and is active
            # inward_exists = yarn_inward_table.objects.filter(id=delivery.inward_id, status=1).exists()
            # if not inward_exists:
                # return JsonResponse({'message': 'inward not active'})

            # Proceed with soft delete
            parent_gf_delivery_table.objects.filter(id=data_id).update(status=0, is_active=0)
            child_gf_delivery_table.objects.filter(tm_id=data_id).update(status=0, is_active=0)

            return JsonResponse({'message': 'yes'})

        except Exception as e:
            return JsonResponse({'message': 'error', 'error_message': str(e)})

    return JsonResponse({'message': 'Invalid request method'})






def outward_detail_lists(request):
    if request.method == 'POST':
        master_id = request.POST.get('tm_id')
        print('po-out-tmid:',master_id)
        if master_id:
            try:
                child_data = child_gf_delivery_table.objects.filter(tm_id=master_id, status=1)

                if not child_data.exists():
                    return JsonResponse({'success': True, 'data': []})  # still return success with empty data

                formatted_data = []
                for index, item in enumerate(child_data, start=1):
                    formatted_data.append({
                        'action': f'''
                            <button type="button" onclick="inward_detail_edit('{item.id}')" class="btn btn-primary btn-xs">
                                <i class="feather icon-edit"></i>
                            </button>
                            <button type="button" onclick="inward_detail_delete('{item.id}')" class="btn btn-danger btn-xs">
                                <i class="feather icon-trash-2"></i>
                            </button>
                        ''',
                        'fabric': getItemFabNameById(fabric_program_table, item.fabric_id),
                        'yarn_count': getItemNameById(count_table, item.yarn_count_id),
                        'tex': getItemNameById(tex_table, item.tex_id),
                        'gauge': getItemNameById(gauge_table, item.gauge_id),
                        'gsm': item.gsm,
                        'dia': getItemNameById(dia_table, item.dia_id),
                        'roll': item.roll or 0,
                        'total_wt': item.roll_wt or 0,
                        'gross_wt': item.gross_wt or 0,
                        'received_roll': 0,
                        'received_roll_wt': 0,
                        'fabric_id': item.fabric_id or '-',
                        'yarn_count_id': item.yarn_count_id or '-',
                        'tex_id': item.tex_id or '-',
                        'gauge_id': item.gauge_id or '-',
                        'dia_id': item.dia_id or '-',
                    })

                return JsonResponse({'success': True, 'data': formatted_data})
            except Exception as e:
                return JsonResponse({'success': False, 'error': str(e)})
        else:
            return JsonResponse({'success': False, 'error': 'Invalid request, missing ID parameter'})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})





def update_grey_outward(request):
    if request.method == 'POST':
        try:
            user_id = request.session.get('user_id')
            company_id = request.session.get('company_id')

            master_id = request.POST.get('tm_id')
            if not master_id:
                return JsonResponse({'success': False, 'error_message': 'Missing tm_id'})

            # Get and parse table data
            chemical_data = request.POST.get('chemical_data')
            if not chemical_data:
                return JsonResponse({'success': False, 'error_message': 'Missing table data'})

            table_data = json.loads(chemical_data)

            if not table_data:
                return JsonResponse({'success': False, 'error_message': 'Table data is empty'})

            # Step 1: Delete previous entries with status = 0
            # sub_gf_inward_table.objects.filter(tm_id=master_id).update(status=0,is_active=0)
            child_gf_delivery_table.objects.filter(tm_id=master_id).delete() 

            # Step 2: Create new entries
            for row in table_data:     

                child_gf_delivery_table.objects.create(
                    tm_id=master_id, 
                    company_id=company_id,
                    cfyear=2025,
                    roll=row.get('roll'),
                    gross_wt=row.get('gross_wt'), 
                    roll_wt=row.get('total_wt'), 
                    program_id=row.get('program_id'),
                    lot_no=row.get('lot_no'),

                    party_id=row.get('supplier_id') or 0,

                    yarn_count_id=row.get('yarn_count_id'),
                    fabric_id=row.get('fabric_id'),
                    gauge_id=row.get('gauge_id'),
                    tex_id=row.get('tex_id'),
                    gsm=row.get('gsm'),
                    dia_id=row.get('dia_id'),

                    status=1,
                    is_active=1,
                    created_by=user_id,
                    updated_by=user_id,
                    created_on=datetime.now(),
                    updated_on=datetime.now(),
                )

            # Step 3: Update master totals
            updated_totals = update_inwards_total(master_id)
            if 'error' in updated_totals:
                return JsonResponse({'success': False, 'error_message': updated_totals['error']})

            return JsonResponse({'success': True, **updated_totals})

        except Exception as e:
            return JsonResponse({'success': False, 'error_message': str(e)})

    return JsonResponse({'success': False, 'error_message': 'Invalid request method'})

 
def update_inwards_total(master_id):
    try:
        qs = child_gf_delivery_table.objects.filter(tm_id=master_id, status=1, is_active=1)

        if not qs.exists():
            return {'error': 'No active inward items found.'}

        # Use Django ORM's Sum aggregation
        totals = qs.aggregate(
            total_wt=Sum('total_wt'),
            gross_wt=Sum('gross_wt')
        )

        total_wt = totals['total_wt'] or Decimal('0')
        gross_wt = totals['gross_wt'] or Decimal('0')

        parent_gf_delivery_table.objects.filter(id=master_id).update(
            total_wt=total_wt,
            total_gross_wt=gross_wt,
            updated_on=datetime.now()
        )

        return {
            'total_wt': str(total_wt),
            'total_gross': str(gross_wt),
        }

    except Exception as e: 
        return {'error': str(e)}
    
